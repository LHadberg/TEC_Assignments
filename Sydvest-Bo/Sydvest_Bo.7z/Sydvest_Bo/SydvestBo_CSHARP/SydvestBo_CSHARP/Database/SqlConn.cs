﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace SydvestBo_CSHARP.Database
{
    public static class SqlConn
    {
        #region Åbner/Lukker SQL Connection
        public static SqlDataAdapter dataAdapter;
        //public static string connectionString = @"Data Source=SKAB1-PC-08\GALH1;Initial Catalog=SydvestBoDB;User ID=sa;Password=Passw0rd"; //Galberts
        public static string connectionString = @"Data Source=SKAB1-PC-10\H1SQLSERVER;Initial Catalog=SydvestBoDB;User ID=sa;Password=Passw0rd"; //Lasses med hatten
        //public static string connectionString = @"Data Source=DESKTOP-UE671U5\H1SQLSERVER;Initial Catalog=SydvestBoDB;User ID=Dani;Password=Passw0rd"; //Dunkels
        //public static string connectionString = @"Data Source=DESKTOP-18VPIO6;Initial Catalog=SydvestBoDB;User ID=sa;Password=Passw0rd"; //Dunkels Hjemme PC
        public static SqlConnection cnn;
        public static void cnnOpen()
        {
            try
            {
                cnn = new SqlConnection(connectionString);
                cnn.Open();
            }
            catch (Exception)
            {
                Console.WriteLine("The connection has failed.");
                Console.ReadKey();
            }
        }
        public static void cnnClose()
        {
            cnn.Close();
            Console.WriteLine("The connection is closed");
        }
        #endregion
        #region Executer SQL commands
        public static void Execute(string sql)
        {
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                cnn.Open();
                SqlCommand cmd = new SqlCommand(sql, cnn);
                cmd.ExecuteNonQuery();
            }
        }
        #endregion
        #region Læser forbindelsen ind i Records
        public static DataTable ReadTable(string sql)
        {
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                DataTable records = new DataTable();
                using (SqlDataAdapter a = new SqlDataAdapter(sql, cnn))
                {
                    cnnOpen();
                    a.Fill(records);
                }
                return records;
            }
        }
        #endregion
    }
}
