﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
using System.Data;
using System.Data.SqlClient;
namespace SydvestBo_CSHARP
{
    class PersAdmin
    {
        #region Menu til Person-Administration
        public void UnderMenu()
        {
            //
            string[] valg = new string[] { "    Kunder", "    Husejere", "    Udlejningskonsulenter", "    Opsynsmænd" };
            Menu m = new Menu(valg, valg.Length);
            Kunder Kunde = new Kunder();
            Husejer Husejer = new Husejer();
            Udlejningskonsulenter Udkon = new Udlejningskonsulenter();
            Opsynsmænd opsynsmænd = new Opsynsmænd();
            bool t = true;
            do
            {
                switch (m.SMenu())
                {
                    case 1:
                        Kunde.KundeMenu();
                        break;
                    case 2:
                        Husejer.HusejerMenu();
                        break;
                    case 3:
                        Udkon.UdKonMenu();
                        break;
                    case 4:
                        opsynsmænd.OpsynsmændMenu();
                        break;
                    case -1:
                        t = false;
                        break;

                }
            } while (t == true);
        }
    #endregion
    }
    class Kunder
    {
        #region Properties
        public int PersonID { get; set; }
        public string Fornavn { get; set; }
        public string Efternavn { get; set; }
        public string TypeNavn { get; set; }
        public string Adresse { get; set; }
        public int PostNr { get; set; }
        public string Email { get; set; }
        public int TlfNr { get; set; }
        #endregion
        #region Kundeconstructors
        public Kunder() { }
        public Kunder(int personID, string fornavn, string efternavn, string typeNavn, string adresse, int postNr, string email, int tlfNr)
        {
            PersonID = personID;
            Fornavn = fornavn;
            Efternavn = efternavn;
            TypeNavn = typeNavn;
            Adresse = adresse;
            PostNr = postNr;
            Email = email;
            TlfNr = tlfNr;
        }
        #endregion
        #region Menu til Kunder
        public void KundeMenu()
        {
            string[] valg = new string[] { "    Opret Kunde", "    Vis Kunde", "    Rediger Kunde", "    Fjern Kunde" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        KundeCreate();
                        break;
                    case 2:
                        Console.Clear();
                        KundeRead();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        KunderUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        KundeDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Kunde
        public void KundeCreate()
        {
            Console.CursorVisible = true;
            string Fornavn;
            string Efternavn;
            string Adresse;
            int PostNr;
            string Email;
            int TlfNr;
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.SetCursorPosition(21, 0);
            Fornavn = Console.ReadLine();
            Console.SetCursorPosition(21, 1);
            Efternavn = Console.ReadLine();
            Console.SetCursorPosition(21, 2);
            Adresse = Console.ReadLine();
            Console.SetCursorPosition(21, 3);
            PostNr = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(21, 4);
            Email = Console.ReadLine();
            Console.SetCursorPosition(21, 5);
            TlfNr = Convert.ToInt32(Console.ReadLine());
            string sql = "insert into PersonTabel values ('" + Fornavn + "', '" + Efternavn + "', 'Kunde', '" + Adresse + "', " + PostNr + ", '" + Email + "', " + TlfNr + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Ny Kunde oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {

                Console.WriteLine("Der opstod en fejl i oprettelsen, kunden IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Read Kunde Database
        public void KundeRead()
        {
            string sql = "select * from PersonTabel";
            DataTable KunderDataTable = SqlConn.ReadTable(sql);
            List<Kunder> Kunde = new List<Kunder>();
            foreach (DataRow item in KunderDataTable.Rows)
            {
                Kunde.Add(new Kunder()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in Kunde)
            {
                if (item.TypeNavn == "Kunde")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
        }
        #endregion
        #region Delete Kunde
        public void KundeDelete()
        {
            bool forsæt = true;
            do
            {
                int deleteID;
                ConsoleKey keypressed;
                string sql = "select * from PersonTabel";
                DataTable KunderDataTable = SqlConn.ReadTable(sql);
                List<Kunder> Kunde = new List<Kunder>();
                foreach (DataRow item in KunderDataTable.Rows)
                {
                    Kunde.Add(new Kunder()
                    {
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        Fornavn = item["Fornavn"].ToString(),
                        Efternavn = item["Efternavn"].ToString(),
                        TypeNavn = item["TypeNavn"].ToString(),
                        Adresse = item["Adresse"].ToString(),
                        PostNr = Convert.ToInt32(item["PostNr"]),
                        Email = item["Email"].ToString(),
                        TlfNr = Convert.ToInt32(item["TlfNr"])
                    });
                }
                foreach (var item in Kunde)
                {
                    if (item.TypeNavn == "Kunde")
                    {
                        Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                    }
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from PersonTabel where PersonID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Kunde slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, kunde IKKE slettet");
                }
                Console.Clear();
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
                Console.Clear();
            } while (forsæt == true);
        }
        #endregion
        #region Update Kunde
        public void KunderUpdate()
        {
            int UpdateID;
            string sql = "select * from PersonTabel";
            DataTable KundeDataTable = SqlConn.ReadTable(sql);
            List<Kunder> kunde = new List<Kunder>();
            foreach (DataRow item in KundeDataTable.Rows)
            {
                kunde.Add(new Kunder()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in kunde)
            {
                if (item.TypeNavn == "Kunde")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
            Console.Write("\nSkriv ID på hvem du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.WriteLine("\n\n");

            foreach (var item in kunde)
            {
                if (item.PersonID == UpdateID)
                {
                    string fornavn;
                    string efternavn;
                    string adresse;
                    int postnr;
                    string email;
                    int tlfnr;
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");

                    Console.SetCursorPosition(21, 0);
                    fornavn = Console.ReadLine();
                    if (fornavn == "") fornavn = item.Fornavn;
                    Console.SetCursorPosition(21, 1);
                    efternavn = Console.ReadLine();
                    if (efternavn == "") efternavn = item.Efternavn;
                    Console.SetCursorPosition(21, 2);
                    adresse = Console.ReadLine();
                    if (adresse == "") adresse = item.Adresse;
                    Console.SetCursorPosition(21, 3);
                    try
                    {
                        postnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        postnr = item.PostNr;
                    }
                    Console.SetCursorPosition(21, 4);
                    email = Console.ReadLine();
                    if (email == "") email = item.Email;
                    Console.SetCursorPosition(21, 5);
                    try
                    {
                        tlfnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        tlfnr = item.TlfNr;
                    }
                    Console.Clear();

                    sql = "UPDATE PersonTabel SET Fornavn = '" + fornavn + "', Efternavn = '" + efternavn + "', Adresse = '" + adresse + "', PostNr = " + postnr + ", Email = '" + email + "', TlfNr = " + tlfnr + " WHERE PersonID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Husejer opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, husejer IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
    class Husejer
    {
        #region Properties
        public int PersonID { get; set; }
        public string Fornavn { get; set; }
        public string Efternavn { get; set; }
        public string TypeNavn { get; set; }
        public string Adresse { get; set; }
        public int PostNr { get; set; }
        public string Email { get; set; }
        public int TlfNr { get; set; }
        #endregion
        #region Husejerconstructors
        public Husejer(){}
        public Husejer(int personID, string fornavn, string efternavn, string typeNavn, string adresse, int postNr, string email, int tlfNr)
        {
            PersonID = personID;
            Fornavn = fornavn;
            Efternavn = efternavn;
            TypeNavn = typeNavn;
            Adresse = adresse;
            PostNr = postNr;
            Email = email;
            TlfNr = tlfNr;
        }
        #endregion
        #region Menu til Husejere
        public void HusejerMenu()
        {
            string[] valg = new string[] { "    Opret Husejere", "    Vis Husejere", "    Rediger Husejere", "    Fjern Husejere" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        HusejerCreate();
                        break;
                    case 2:
                        Console.Clear();
                        HusejerRead();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        HusejerUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        HusejerDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Husejer
        public void HusejerCreate()
        {
            Console.CursorVisible = true;
            string Fornavn;
            string Efternavn;
            string Adresse;
            int PostNr;
            string Email;
            int TlfNr;
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.SetCursorPosition(21, 0);
            Fornavn = Console.ReadLine();
            Console.SetCursorPosition(21, 1);
            Efternavn = Console.ReadLine();
            Console.SetCursorPosition(21, 2);
            Adresse = Console.ReadLine();
            Console.SetCursorPosition(21, 3);
            PostNr = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(21, 4);
            Email = Console.ReadLine();
            Console.SetCursorPosition(21, 5);
            TlfNr = Convert.ToInt32(Console.ReadLine());
            string sql = "insert into PersonTabel values ('" + Fornavn + "', '" + Efternavn + "', 'Sommerhusejer', '" + Adresse + "', " + PostNr + ", '" + Email + "', " + TlfNr + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Ny husejer oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {

                Console.WriteLine("Der opstod en fejl i oprettelsen, husejeren IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Read Husejer Database
        public void HusejerRead()
        {
            string sql = "select * from PersonTabel";
            DataTable HusejerDataTable = SqlConn.ReadTable(sql);
            List<Husejer> Huseje = new List<Husejer>();
            foreach (DataRow item in HusejerDataTable.Rows)
            {
                Huseje.Add(new Husejer()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in Huseje)
            {
                if (item.TypeNavn == "Sommerhusejer")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
        }
        #endregion
        #region Delete Husejer
        public void HusejerDelete()
        {
            bool forsæt = true;
            do
            {
                int deleteID;
                ConsoleKey keypressed;
                string sql = "select * from PersonTabel";
                DataTable HusejerDataTable = SqlConn.ReadTable(sql);
                List<Husejer> Huseje = new List<Husejer>();
                foreach (DataRow item in HusejerDataTable.Rows)
                {
                    Huseje.Add(new Husejer()
                    {
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        Fornavn = item["Fornavn"].ToString(),
                        Efternavn = item["Efternavn"].ToString(),
                        TypeNavn = item["TypeNavn"].ToString(),
                        Adresse = item["Adresse"].ToString(),
                        PostNr = Convert.ToInt32(item["PostNr"]),
                        Email = item["Email"].ToString(),
                        TlfNr = Convert.ToInt32(item["TlfNr"])
                    });
                }
                foreach (var item in Huseje)
                {
                    if (item.TypeNavn == "Sommerhusejer")
                    {
                        Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                    }
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from PersonTabel where PersonID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Husejer slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, husejer IKKE slettet");
                }
                Console.Clear();
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
                Console.Clear();
            } while (forsæt == true);
        }
        #endregion
        #region Update Husejer
        public void HusejerUpdate()
        {
            int UpdateID;
            string sql = "select * from PersonTabel";
            DataTable HusejerDataTable = SqlConn.ReadTable(sql);
            List<Husejer> husejer = new List<Husejer>();
            foreach (DataRow item in HusejerDataTable.Rows)
            {
                husejer.Add(new Husejer()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in husejer)
            {
                if (item.TypeNavn == "Sommerhusejer")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
            Console.Write("\nSkriv ID på hvem du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.WriteLine("\n\n");

            foreach (var item in husejer)
            {
                if (item.PersonID == UpdateID)
                {
                    string fornavn;
                    string efternavn;
                    string adresse;
                    int postnr;
                    string email;
                    int tlfnr;
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");

                    Console.SetCursorPosition(21, 0);
                    fornavn = Console.ReadLine();
                    if (fornavn == "") fornavn = item.Fornavn;
                    Console.SetCursorPosition(21, 1);
                    efternavn = Console.ReadLine();
                    if (efternavn == "") efternavn = item.Efternavn;
                    Console.SetCursorPosition(21, 2);
                    adresse = Console.ReadLine();
                    if (adresse == "") adresse = item.Adresse;
                    Console.SetCursorPosition(21, 3);
                    try
                    {
                        postnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        postnr = item.PostNr;
                    }
                    Console.SetCursorPosition(21, 4);
                    email = Console.ReadLine();
                    if (email == "") email = item.Email;
                    Console.SetCursorPosition(21, 5);
                    try
                    {
                        tlfnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        tlfnr = item.TlfNr;
                    }
                    Console.Clear();

                    sql = "UPDATE PersonTabel SET Fornavn = '" + fornavn + "', Efternavn = '" + efternavn + "', Adresse = '" + adresse + "', PostNr = " + postnr + ", Email = '" + email + "', TlfNr = " + tlfnr + " WHERE PersonID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Husejer opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, husejer IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
    class Udlejningskonsulenter
    {
        #region Properties
        public int PersonID { get; set; }
        public string Fornavn { get; set; }
        public string Efternavn { get; set; }
        public string TypeNavn { get; set; }
        public string Adresse { get; set; }
        public int PostNr { get; set; }
        public string Email { get; set; }
        public int TlfNr { get; set; }
        #endregion
        #region Udlejningskonsulentconstructors
        public Udlejningskonsulenter(){}
        public Udlejningskonsulenter(int personID, string fornavn, string efternavn, string typeNavn, string adresse, int postNr, string email, int tlfNr)
        {
            PersonID = personID;
            Fornavn = fornavn;
            Efternavn = efternavn;
            TypeNavn = typeNavn;
            Adresse = adresse;
            PostNr = postNr;
            Email = email;
            TlfNr = tlfNr;
        }
        #endregion
        #region Menu til Udlejningskonsulenter
        public void UdKonMenu()
        {
            string[] valg = new string[] { "    Opret Udlejningskonsulent", "    Vis Udlejningskonsulent", "    Rediger Udlejningskonsulent", "    Fjern Udlejningskonsulent" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        UdlejKonCreate();
                        break;
                    case 2:
                        Console.Clear();
                        UdlejningskonsulenterRead();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        UdlejningskonsulenterUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        UdlejningskonsulenterDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Udlejningskonsulent
        public void UdlejKonCreate()
        {
            Console.CursorVisible = true;
            string Fornavn;
            string Efternavn;
            string Adresse;
            int PostNr;
            string Email;
            int TlfNr;
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.SetCursorPosition(21, 0);
            Fornavn = Console.ReadLine();
            Console.SetCursorPosition(21, 1);
            Efternavn = Console.ReadLine();
            Console.SetCursorPosition(21, 2);
            Adresse = Console.ReadLine();
            Console.SetCursorPosition(21, 3);
            PostNr = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(21, 4);
            Email = Console.ReadLine();
            Console.SetCursorPosition(21, 5);
            TlfNr = Convert.ToInt32(Console.ReadLine());
            string sql = "insert into PersonTabel values ('" + Fornavn + "', '" + Efternavn + "', 'Udlejningskonsulent', '" + Adresse + "', " + PostNr + ", '" + Email + "', " + TlfNr + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Ny udlejningskonsulent oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {

                Console.WriteLine("Der opstod en fejl i oprettelsen, udlejningskonsulent IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Read Udlejningskonsulent Database
        public void UdlejningskonsulenterRead()
        {
            string sql = "select * from PersonTabel";
            DataTable UdlejningskonsulenterDataTable = SqlConn.ReadTable(sql);
            List<Udlejningskonsulenter> Udlejningskonsulent = new List<Udlejningskonsulenter>();
            foreach (DataRow item in UdlejningskonsulenterDataTable.Rows)
            {
                Udlejningskonsulent.Add(new Udlejningskonsulenter()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in Udlejningskonsulent)
            {
                if (item.TypeNavn == "Udlejningskonsulent")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
        }
        #endregion
        #region Delete Udlejningskonsulent
        public void UdlejningskonsulenterDelete()
        {
            bool forsæt = true;
            do
            {
                ConsoleKey keypressed;
                int deleteID;
                string sql = "select * from PersonTabel";
                DataTable UdlejningskonsulenterDataTable = SqlConn.ReadTable(sql);
                List<Udlejningskonsulenter> Udlejningskonsulent = new List<Udlejningskonsulenter>();
                foreach (DataRow item in UdlejningskonsulenterDataTable.Rows)
                {
                    Udlejningskonsulent.Add(new Udlejningskonsulenter()
                    {
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        Fornavn = item["Fornavn"].ToString(),
                        Efternavn = item["Efternavn"].ToString(),
                        TypeNavn = item["TypeNavn"].ToString(),
                        Adresse = item["Adresse"].ToString(),
                        PostNr = Convert.ToInt32(item["PostNr"]),
                        Email = item["Email"].ToString(),
                        TlfNr = Convert.ToInt32(item["TlfNr"])
                    });
                }
                foreach (var item in Udlejningskonsulent)
                {
                    if (item.TypeNavn == "Udlejningskonsulent")
                    {
                        Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                    }
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from PersonTabel where PersonID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Udlejningskonsulent slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, udlejningskonsulent IKKE slettet");
                }
                Console.Clear();
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
                Console.Clear();
            } while (forsæt == true);
        }
        #endregion
        #region Update Udlejningskonsulent
        public void UdlejningskonsulenterUpdate()
        {
            int UpdateID;
            string sql = "select * from PersonTabel";
            DataTable UdlejningskonsulenterDataTable = SqlConn.ReadTable(sql);
            List<Udlejningskonsulenter> udlejningskonsulent = new List<Udlejningskonsulenter>();
            foreach (DataRow item in UdlejningskonsulenterDataTable.Rows)
            {
                udlejningskonsulent.Add(new Udlejningskonsulenter()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in udlejningskonsulent)
            {
                if (item.TypeNavn == "Udlejningskonsulent")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
            Console.Write("\nSkriv ID på hvem du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.WriteLine("\n\n");

            foreach (var item in udlejningskonsulent)
            {
                if (item.PersonID == UpdateID)
                {
                    string fornavn;
                    string efternavn;
                    string adresse;
                    int postnr;
                    string email;
                    int tlfnr;
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");

                    Console.SetCursorPosition(21, 0);
                    fornavn = Console.ReadLine();
                    if (fornavn == "") fornavn = item.Fornavn;
                    Console.SetCursorPosition(21, 1);
                    efternavn = Console.ReadLine();
                    if (efternavn == "") efternavn = item.Efternavn;
                    Console.SetCursorPosition(21, 2);
                    adresse = Console.ReadLine();
                    if (adresse == "") adresse = item.Adresse;
                    Console.SetCursorPosition(21, 3);
                    try
                    {
                        postnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        postnr = item.PostNr;
                    }
                    Console.SetCursorPosition(21, 4);
                    email = Console.ReadLine();
                    if (email == "") email = item.Email;
                    Console.SetCursorPosition(21, 5);
                    try
                    {
                        tlfnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        tlfnr = item.TlfNr;
                    }
                    Console.Clear();

                    sql = "UPDATE PersonTabel SET Fornavn = '" + fornavn + "', Efternavn = '" + efternavn + "', Adresse = '" + adresse + "', PostNr = " + postnr + ", Email = '" + email + "', TlfNr = " + tlfnr + " WHERE PersonID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Udlejningskonsulent opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, udlejningskonsulent IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
    class Opsynsmænd
    {
        #region Properties
        public int PersonID { get; set; }
        public string Fornavn { get; set; }
        public string Efternavn { get; set; }
        public string TypeNavn { get; set; }
        public string Adresse { get; set; }
        public int PostNr { get; set; }
        public string Email { get; set; }
        public int TlfNr { get; set; }
        #endregion
        #region Opsynsmandsconstructor
        public Opsynsmænd(){}
        public Opsynsmænd(int personID, string fornavn, string efternavn, string typeNavn, string adresse, int postNr, string email, int tlfNr)
        {
            PersonID = personID;
            Fornavn = fornavn;
            Efternavn = efternavn;
            TypeNavn = typeNavn;
            Adresse = adresse;
            PostNr = postNr;
            Email = email;
            TlfNr = tlfNr;
        }
        #endregion
        #region Menu til Opsynsmænd
        public void OpsynsmændMenu()
        {
            string[] valg = new string[] { "    Opret Opsynsmænd", "    Vis Opsynsmænd", "    Rediger Opsynsmænd", "    Fjern Opsynsmænd" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        OpsynsmændCreate();
                        break;
                    case 2:
                        Console.Clear();
                        OpsynsmændRead();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        OpsynsmændUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        OpsynsmændDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Opsynsmand
        public void OpsynsmændCreate()
        {
            Console.CursorVisible = true;
            string Fornavn;
            string Efternavn;
            string Adresse;
            int PostNr;
            string Email;
            int TlfNr;
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.SetCursorPosition(21, 0);
            Fornavn = Console.ReadLine();
            Console.SetCursorPosition(21, 1);
            Efternavn = Console.ReadLine();
            Console.SetCursorPosition(21, 2);
            Adresse = Console.ReadLine();
            Console.SetCursorPosition(21, 3);
            PostNr = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(21, 4);
            Email = Console.ReadLine();
            Console.SetCursorPosition(21, 5);
            TlfNr = Convert.ToInt32(Console.ReadLine());
            string sql = "insert into PersonTabel values ('" + Fornavn + "', '" + Efternavn + "', 'Opsynsmand', '" + Adresse + "', " + PostNr + ", '" + Email + "', " + TlfNr + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Ny opsynsmand oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {
                Console.WriteLine("Der opstod en fejl i oprettelsen, opsynsmand IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Read Opsynsmænd Database
        public void OpsynsmændRead()
        {
            string sql = "select * from PersonTabel";
            DataTable OpsynsmændDataTable = SqlConn.ReadTable(sql);
            List<Opsynsmænd> opsynsmænd = new List<Opsynsmænd>();
            foreach (DataRow item in OpsynsmændDataTable.Rows)
            {
                opsynsmænd.Add(new Opsynsmænd()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in opsynsmænd)
            {
                if (item.TypeNavn == "Opsynsmand")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
        }
        #endregion
        #region Delete Opsynsmand
        public void OpsynsmændDelete()
        {
            bool forsæt = true;
            do
            {
                ConsoleKey keypressed;
                int deleteID;
                string sql = "select * from PersonTabel";
                DataTable OpsynsmændDataTable = SqlConn.ReadTable(sql);
                List<Opsynsmænd> opsynsmænd = new List<Opsynsmænd>();
                foreach (DataRow item in OpsynsmændDataTable.Rows)
                {
                    opsynsmænd.Add(new Opsynsmænd()
                    {
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        Fornavn = item["Fornavn"].ToString(),
                        Efternavn = item["Efternavn"].ToString(),
                        TypeNavn = item["TypeNavn"].ToString(),
                        Adresse = item["Adresse"].ToString(),
                        PostNr = Convert.ToInt32(item["PostNr"]),
                        Email = item["Email"].ToString(),
                        TlfNr = Convert.ToInt32(item["TlfNr"])
                    });
                }
                foreach (var item in opsynsmænd)
                {
                    if (item.TypeNavn == "Opsynsmand")
                    {
                        Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                    }
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from PersonTabel where PersonID=" + deleteID;
                try
                {
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Opsynsmand slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, opsynsmand IKKE slettet");
                }
                Console.Clear();
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
                Console.Clear();
            } while (forsæt == true);
        }
        #endregion
        #region Update Opsynsmand
        public void OpsynsmændUpdate()
        {
            int UpdateID;
            string sql = "select * from PersonTabel";
            DataTable OpsynsmændDataTable = SqlConn.ReadTable(sql);
            List<Opsynsmænd> opsynsmænd = new List<Opsynsmænd>();
            foreach (DataRow item in OpsynsmændDataTable.Rows)
            {
                opsynsmænd.Add(new Opsynsmænd()
                {
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Fornavn = item["Fornavn"].ToString(),
                    Efternavn = item["Efternavn"].ToString(),
                    TypeNavn = item["TypeNavn"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    PostNr = Convert.ToInt32(item["PostNr"]),
                    Email = item["Email"].ToString(),
                    TlfNr = Convert.ToInt32(item["TlfNr"])
                });
            }
            foreach (var item in opsynsmænd)
            {
                if (item.TypeNavn == "Opsynsmand")
                {
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                }
            }
            Console.Write("\nSkriv ID på hvem du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Fornavn    : ");
            Console.Write("\nIndtast Efternavn  : ");
            Console.Write("\nIndtast Adresse    : ");
            Console.Write("\nIndtast PostNr     : ");
            Console.Write("\nIndtast Email      : ");
            Console.Write("\nIndtast TlfNr      : ");
            Console.WriteLine("\n\n");

            foreach (var item in opsynsmænd)
            {
                if (item.PersonID == UpdateID)
                {
                    string fornavn;
                    string efternavn;
                    string adresse;
                    int postnr;
                    string email;
                    int tlfnr;
                    Console.WriteLine("PersonID: " + item.PersonID + "\nNavn: " + item.Fornavn + " " + item.Efternavn + "\nTypenavn: " + item.TypeNavn + "\nAdresse: " + item.Adresse + "\nPost nr: " + item.PostNr + "\nEmail: " + item.Email + "\nTelefon nr: " + item.TlfNr + "\n\n");
                    
                    Console.SetCursorPosition(21, 0);
                    fornavn = Console.ReadLine();
                    if (fornavn == "") fornavn = item.Fornavn;
                    Console.SetCursorPosition(21, 1);
                    efternavn = Console.ReadLine();
                    if (efternavn == "") efternavn = item.Efternavn;
                    Console.SetCursorPosition(21, 2);
                    adresse = Console.ReadLine();
                    if (adresse == "") adresse = item.Adresse;
                    Console.SetCursorPosition(21, 3);
                    try
                    {
                        postnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        postnr = item.PostNr;
                    }
                    Console.SetCursorPosition(21, 4);
                    email = Console.ReadLine();
                    if (email == "") email = item.Email;
                    Console.SetCursorPosition(21, 5);
                    try
                    {
                        tlfnr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        tlfnr = item.TlfNr;
                    }
                    Console.Clear();

                    sql = "UPDATE PersonTabel SET Fornavn = '" + fornavn + "', Efternavn = '" + efternavn + "', Adresse = '" + adresse + "', PostNr = " + postnr + ", Email = '" + email + "', TlfNr = " + tlfnr + " WHERE PersonID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Opsynsmand opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, opsynsmand IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
}