﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
using System.Data;
using System.Data.SqlClient;
namespace SydvestBo_CSHARP
{
    class SaesonKat
    {
        #region Menu til Saesonkategorier
        public void UnderMenu()
        {
            string[] valg = new string[] { "    Vis Sæsonkategori", "    Rediger Sæsonkategori" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        SKList();
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.Clear();
                        SaesonKatUpdate();
                        Console.ReadKey();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Properties
        public int UgeNr { get; set; }
        public string KatNavn { get; set; }
        #endregion
        #region Reservationsconstructors
        public SaesonKat() { }
        public SaesonKat(int ugenr, string katnavn)
        {
            UgeNr = ugenr;
            KatNavn = katnavn;
        }
        #endregion
        #region Read Saeson-Kategori Database
        public static void SKList()
        {
            string sql = "select * from SaesonKategorier";
            DataTable SaesonKatDataTable = SqlConn.ReadTable(sql);
            List<SaesonKat> saesonkat = new List<SaesonKat>();

            foreach (DataRow item in SaesonKatDataTable.Rows)
            {
                saesonkat.Add(new SaesonKat()
                {
                    UgeNr = Convert.ToInt32(item["UgeNr"]),
                    KatNavn = item["KategoriNavn"].ToString()
                });
            }
            foreach (var item in saesonkat)
            {
                Console.WriteLine("UgeNr: {0}\nKategoritype: {1}\n", item.UgeNr, item.KatNavn);
            }
        }
        #endregion
        #region Update Sæsonkategori
        public void SaesonKatUpdate()
        {
            int UpdateID;
            string sql = "select * from SaesonKategorier";
            DataTable SaesonKatDataTable = SqlConn.ReadTable(sql);
            List<SaesonKat> Kat = new List<SaesonKat>();

            foreach (DataRow item in SaesonKatDataTable.Rows)
            {
                Kat.Add(new SaesonKat()
                {
                    UgeNr = Convert.ToInt32(item["UgeNr"]),
                    KatNavn = item["KategoriNavn"].ToString()
                });
            }
            foreach (var item in Kat)
            {
                Console.WriteLine("UgeNr: {0}\nKategoritype: {1}\n", item.UgeNr, item.KatNavn);
            }
            Console.Write("\nSkriv uge nr på hvilken uge du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Skriv: Lav, Normal, Høj eller Super");
            Console.Write("Indtast kategori : ");
            Console.WriteLine("\n\n");

            foreach (var item in Kat)
            {
                if (item.UgeNr == UpdateID)
                {
                    string katnavn;
                    Console.WriteLine("UgeNr: {0}\nKategoritype: {1}\n\n", item.UgeNr, item.KatNavn);

                    Console.SetCursorPosition(21, 1);
                    katnavn = Console.ReadLine();
                    if (katnavn == "") katnavn = item.KatNavn;
                    
                    Console.Clear();

                    sql = "UPDATE SaesonKategorier SET KategoriNavn = '" + katnavn + "' WHERE UgeNr = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Sæsonkategori opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, sæsonkategori IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
}
