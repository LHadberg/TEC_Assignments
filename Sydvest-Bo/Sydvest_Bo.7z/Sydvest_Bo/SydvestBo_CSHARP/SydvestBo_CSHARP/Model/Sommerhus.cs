﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
using System.Data;
using System.Data.SqlClient;
namespace SydvestBo_CSHARP
{
    class Sommerhus
    {
        #region Properties
        public int HusID { get; set; }
        public int OmdraadeID { get; set; }
        public int KlasseID { get; set; }
        public int PersonID { get; set; }
        public string Beskrivelse { get; set; }
        public string Navn { get; set; }
        public string Adresse { get; set; }
        #endregion
        #region Sommerhusconstructors
        public Sommerhus(){}
        public Sommerhus(int husid,int omraadeid,int klasseid,int personid,string beskrivelse,string navn,string adresse)
        {
            HusID = husid;
            OmdraadeID = omraadeid;
            KlasseID = klasseid;
            PersonID = personid;
            Beskrivelse = beskrivelse;
            Navn = navn;
            Adresse = adresse;
        }
        #endregion
        #region Menu til Sommerhus
        public void Smhus()
        {
            string[] valg = new string[] { "    Create", "    Read", "    Update", "    Delete","    Lookup" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        ShCreate();
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.Clear();
                        ShRead();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        SommerhusUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        ShDelete();
                        break;
                    case 5:
                        Console.Clear();
                        Lookup.ShLookup();
                        Console.ReadKey();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Sommerhus
        public void ShCreate()
        {
            Console.CursorVisible = true;
            int OmrådeID;
            int KlasseID;
            int PersonID;
            string Adresse;
            string Beskrivelse;
            Console.Write("Indtast område ID   : ");
            Console.Write("\nIndtast klasse ID   : ");
            Console.Write("\nIndtast Person ID   : ");
            Console.Write("\nIndtast Adresse     : ");
            Console.Write("\nIndtast Beskrivelse : ");
            Console.SetCursorPosition(22, 0);
            OmrådeID = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 1);
            KlasseID = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 2);
            PersonID = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 3);
            Adresse = Console.ReadLine();
            Console.SetCursorPosition(22, 4);
            Beskrivelse = Console.ReadLine();
            string sql = "insert into SommerhusTabel values (" + OmrådeID + ", " + KlasseID + ", " + PersonID + ", '" + Beskrivelse + "', '" + Adresse + "')";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Nyt sommerhus oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {

                Console.WriteLine("Der opstod en fejl i oprettelsen, sommerhus IKKE oprettet");
                SqlConn.cnnClose();
            }
        }
        #endregion
        #region Read Sommerhus Database
        public static void ShRead()
        {
            string sql = @"select SommerhusTabel.HusID, SommerhusTabel.OmraadeID, SommerhusTabel.KlasseID, SommerhusTabel.PersonID ,SommerhusTabel.Beskrivelse, PersonTabel.Fornavn, PersonTabel.Efternavn,SommerhusTabel.Adresse
from SommerhusTabel,PersonTabel
where SommerhusTabel.PersonID = PersonTabel.PersonID";
            DataTable SommerhusDataTable = SqlConn.ReadTable(sql);
            List<Sommerhus> Sommerhuse = new List<Sommerhus>();
            foreach (DataRow item in SommerhusDataTable.Rows)
            {
                Sommerhuse.Add(new Sommerhus()
                {
                    HusID = Convert.ToInt32(item["HusID"]),
                    OmdraadeID = Convert.ToInt32(item["OmraadeID"]),
                    KlasseID = Convert.ToInt32(item["KlasseID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Adresse = item["Adresse"].ToString(),
                    Beskrivelse = item["Beskrivelse"].ToString(),
                    Navn = item["Fornavn"].ToString()+" "+item["Efternavn"].ToString()
                });
            }
            foreach (var item in Sommerhuse)
            {
                Console.WriteLine("HusID   : {0}\nOmrådeID: {1}\nKlasseID: {2}\nAdresse: {5}\nNavn: {3}\nBeskrivelse: {4}\n",item.HusID,item.OmdraadeID,item.KlasseID,item.Navn,item.Beskrivelse,item.Adresse);
            }
        }
        #endregion
        #region Update Sommerhus
        public void SommerhusUpdate()
        {
            int UpdateID;
            string sql = @"select SommerhusTabel.HusID, SommerhusTabel.OmraadeID, SommerhusTabel.KlasseID, SommerhusTabel.PersonID ,SommerhusTabel.Beskrivelse, PersonTabel.Fornavn, PersonTabel.Efternavn,SommerhusTabel.Adresse
from SommerhusTabel,PersonTabel
where SommerhusTabel.PersonID = PersonTabel.PersonID";
            DataTable SommerhusDataTable = SqlConn.ReadTable(sql);
            List<Sommerhus> Sommerhuse = new List<Sommerhus>();
            foreach (DataRow item in SommerhusDataTable.Rows)
            {
                Sommerhuse.Add(new Sommerhus()
                {
                    HusID = Convert.ToInt32(item["HusID"]),
                    OmdraadeID = Convert.ToInt32(item["OmraadeID"]),
                    KlasseID = Convert.ToInt32(item["KlasseID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    Adresse = item["Adresse"].ToString(),
                    Beskrivelse = item["Beskrivelse"].ToString(),
                    Navn = item["Fornavn"].ToString() + " " + item["Efternavn"].ToString()
                });
            }
            foreach (var item in Sommerhuse)
            {
                Console.WriteLine("HusID   : {0}\nOmrådeID: {1}\nKlasseID: {2}\nAdresse: {5}\nNavn: {3}\nBeskrivelse: {4}\n", item.HusID, item.OmdraadeID, item.KlasseID, item.Navn, item.Beskrivelse, item.Adresse);
            }
            Console.Write("\nSkriv ID på det sommerhus du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast område ID   : ");
            Console.Write("\nIndtast klasse ID   : ");
            Console.Write("\nIndtast Person ID   : ");
            Console.Write("\nIndtast Adresse     : ");
            Console.Write("\nIndtast Beskrivelse : ");
            Console.Write("\n\n");
            foreach (var item in Sommerhuse)
            {
                if (item.HusID == UpdateID)
                {
                    int områdeID;
                    int klasseID;
                    int personID;
                    string adresse;
                    string beskrivelse;
                    Console.WriteLine("OmrådeID: {0}\nKlasseID: {1}\nAdresse: {4}\nNavn: {2}\nBeskrivelse: {3}\n",item.OmdraadeID, item.KlasseID, item.Navn, item.Beskrivelse, item.Adresse);

                    Console.SetCursorPosition(21, 0);
                    try
                    {
                        områdeID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        områdeID = item.OmdraadeID;
                    }

                    Console.SetCursorPosition(21, 1);
                    try
                    {
                        klasseID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        klasseID = item.KlasseID;
                    }

                    Console.SetCursorPosition(21, 2);
                    try
                    {
                        personID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        personID = item.PersonID;
                    }

                    Console.SetCursorPosition(21, 3);
                    adresse = Console.ReadLine();
                    if (adresse == "") adresse = item.Adresse;

                    Console.SetCursorPosition(21, 4);
                    beskrivelse = Console.ReadLine();
                    if (beskrivelse == "") beskrivelse = item.Beskrivelse;

                    Console.Clear();
                    
                    sql = "UPDATE SommerhusTabel SET OmraadeID = " + områdeID + ", KlasseID = " + klasseID + ", PersonID = " + personID + ", Beskrivelse = '" + beskrivelse + "', Adresse = '" + adresse + "' WHERE HusID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Sommerhus opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, sommerhus IKKE opdateret");
                    }
                }
            }
        }
        #endregion
        #region Delete Sommerhus
        public void ShDelete()
        {
            bool forsæt = true;
            do
            {
                int deleteID;
                ConsoleKey keypressed;
                string sql = @"select SommerhusTabel.HusID, SommerhusTabel.OmraadeID, SommerhusTabel.KlasseID, SommerhusTabel.PersonID ,SommerhusTabel.Beskrivelse, PersonTabel.Fornavn, PersonTabel.Efternavn,SommerhusTabel.Adresse
from SommerhusTabel,PersonTabel
where SommerhusTabel.PersonID = PersonTabel.PersonID";
                DataTable SommerhusDataTable = SqlConn.ReadTable(sql);
                List<Sommerhus> Sommerhuse = new List<Sommerhus>();
                foreach (DataRow item in SommerhusDataTable.Rows)
                {
                    Sommerhuse.Add(new Sommerhus()
                    {
                        HusID = Convert.ToInt32(item["HusID"]),
                        OmdraadeID = Convert.ToInt32(item["OmraadeID"]),
                        KlasseID = Convert.ToInt32(item["KlasseID"]),
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        Adresse = item["Adresse"].ToString(),
                        Beskrivelse = item["Beskrivelse"].ToString(),
                        Navn = item["Fornavn"].ToString() + " " + item["Efternavn"].ToString()
                    });
                }
                foreach (var item in Sommerhuse)
                {
                    Console.WriteLine("HusID   : {0}\nOmrådeID: {1}\nKlasseID: {2}\nAdresse: {5}\nNavn: {3}\nBeskrivelse: {4}\n", item.HusID, item.OmdraadeID, item.KlasseID, item.Navn, item.Beskrivelse, item.Adresse);
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from SommerhusTabel where HusID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Sommerhus slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, sommerhus IKKE slettet");
                }
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
            } while (forsæt == true);
        }
        #endregion
    }
    #region Sommerhus Lookup
    public class Lookup
    {
        public string Huslejer { get; set; }
        public string Udlejer { get; set; }
        public string Adresse { get; set; }
        public string Beskrivelse { get; set; }
        public int UgeNr { get; set; }
        public string KategoriNavn { get; set; }
        public Lookup() { }
        public static void ShLookup()
        {
            Console.CursorVisible = true;
            int id;
            Console.Write("Indtast HusID: ");
            id = Convert.ToInt32(Console.ReadLine());
            string sql = @"select
u.Fornavn + ' ' + u.Efternavn Huslejer,
l.Fornavn + ' ' + l.Efternavn Udlejer,
SommerhusTabel.Adresse,
SommerhusTabel.Beskrivelse,
SaesonKategorier.*
from
PersonTabel u
left join Persontabel l ON l.TypeNavn = 'Sommerhusejer'
left join Reservationstabel ON u.PersonID = Reservationstabel.PersonID
left join SommerhusTabel ON SommerhusTabel.HusID = Reservationstabel.HusID AND SommerhusTabel.HusID = "+id+ "left join SaesonKategorier ON Reservationstabel.UgeNr = SaesonKategorier.UgeNr where Reservationstabel.HusID IS NOT NULL AND l.PersonID = SommerhusTabel.PersonID order by ResID; "; 




            DataTable Loookup = SqlConn.ReadTable(sql);
            List<Lookup> Lookuplist = new List<Lookup>();
            foreach (DataRow item in Loookup.Rows)
            {
                Lookuplist.Add(new Lookup()
                {
                    Huslejer = item["Huslejer"].ToString(),
                    Udlejer = item["Udlejer"].ToString(),
                    Adresse = item["Adresse"].ToString(),
                    Beskrivelse = item["Beskrivelse"].ToString(),
                    UgeNr = Convert.ToInt32(item["UgeNr"]),
                    KategoriNavn = item["KategoriNavn"].ToString()
                });
            }
            foreach (var item in Lookuplist)
            {
                Console.Clear();
                Console.WriteLine("Huset lejes af: {0}\nHuset udlejes af: {1}\nAdresse: {2}\nBeskrivelse af huset: {3}\nHuset udlejes i uge: {4}\nHusets priskategori: {5}", item.Huslejer, item.Udlejer, item.Adresse, item.Beskrivelse, item.UgeNr, item.KategoriNavn);
            }
        }
    }
    #endregion
}