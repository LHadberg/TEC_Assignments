﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
using System.Data.SqlClient;
using System.Data;
namespace SydvestBo_CSHARP
{
    class Områder
    {
        #region Menu til Omraader
        public void UnderMenu()
        {
            string[] valg = new string[] { "    Opret Område", "    Vis Område", "    Rediger Område", "    Fjern Område" };
            Menu m = new Menu(valg, valg.Length);
            Menu.Watermark();
            bool t = true;
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        OmrådeCreate();
                        break;
                    case 2:
                        Console.Clear();
                        OmrList();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        OmråderUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        OmrådeDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Omraade
        public void OmrådeCreate()
        {
            Console.Clear();
            Console.CursorVisible = true;
            int PersonID;
            int PostNrID;
            Console.Write("Indtast Person ID   : ");
            Console.Write("\nIndtast Post Nummer : ");
            Console.SetCursorPosition(22, 0);
            PersonID = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 1);
            PostNrID = Convert.ToInt32(Console.ReadLine());
            string sql = "insert into OmraadeTabel values (" + PersonID + ", " + PostNrID + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Nyt Omraade oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {
                Console.WriteLine("Der opstod en fejl i oprettelsen, omraadet er IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Properties
        public int OmraadeID { get; set; }
        public int PersonID { get; set; }
        public int PostNr { get; set; }
        #endregion
        #region Omraadeconstructors
        public Områder() { }
        public Områder(int omraadeid, int personid, int postnr)
        {
            OmraadeID = omraadeid;
            PersonID = personid;
            PostNr = postnr;
        }
        #endregion
        #region Read Område Database
        public static void OmrList()
        {
            string sql = "select * from OmraadeTabel";
            DataTable OmraadeDataTable = SqlConn.ReadTable(sql);
            List<Områder> omraader = new List<Områder>();

            foreach (DataRow item in OmraadeDataTable.Rows)
            {
                omraader.Add(new Områder()
                {
                    OmraadeID = Convert.ToInt32(item["OmraadeID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    PostNr = Convert.ToInt32(item["PostNr"])
                });
            }
            foreach (var item in omraader)
            {
                Console.WriteLine("OmraadeID: {0}\nPersonID: {1}\nPostNr: {2}\n", item.OmraadeID, item.PersonID, item.PostNr);
            }
        }
        #endregion
        #region Delete Område
        public void OmrådeDelete()
        {
            bool forsæt = true;
            do
            {
                int deleteID;
                ConsoleKey keypressed;
                string sql = "select * from OmraadeTabel";
                DataTable OmraadeDataTable = SqlConn.ReadTable(sql);
                List<Områder> omraader = new List<Områder>();

                foreach (DataRow item in OmraadeDataTable.Rows)
                {
                    omraader.Add(new Områder()
                    {
                        OmraadeID = Convert.ToInt32(item["OmraadeID"]),
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        PostNr = Convert.ToInt32(item["PostNr"])
                    });
                }
                foreach (var item in omraader)
                {
                    Console.WriteLine("OmraadeID: {0}\nPersonID: {1}\nPostNr: {2}\n", item.OmraadeID, item.PersonID, item.PostNr);
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from OmraadeTabel where OmraadeID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Område slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, område IKKE slettet");
                }
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
            } while (forsæt == true);
        }
        #endregion
        #region Update Område
        public void OmråderUpdate()
        {
            int UpdateID;
            string sql = "select * from OmraadeTabel";
            DataTable OmraadeDataTable = SqlConn.ReadTable(sql);
            List<Områder> omraader = new List<Områder>();

            foreach (DataRow item in OmraadeDataTable.Rows)
            {
                omraader.Add(new Områder()
                {
                    OmraadeID = Convert.ToInt32(item["OmraadeID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    PostNr = Convert.ToInt32(item["PostNr"])
                });
            }
            foreach (var item in omraader)
            {
                Console.WriteLine("OmraadeID: {0}\nPersonID: {1}\nPostNr: {2}\n", item.OmraadeID, item.PersonID, item.PostNr);
            }
            Console.Write("\nSkriv ID på den område du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Person ID   : ");
            Console.Write("\nIndtast Post Nummer : ");
            Console.Write("\n\n");
            foreach (var item in omraader)
            {
                if (item.OmraadeID == UpdateID)
                {
                    int personID;
                    int postNr;
                    Console.WriteLine("PersonID: {0}\nPostNr: {1}\n", item.PersonID, item.PostNr);

                    Console.SetCursorPosition(21, 0);
                    try
                    {
                        personID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        personID = item.PersonID;
                    }

                    Console.SetCursorPosition(21, 1);
                    try
                    {
                        postNr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        postNr = item.PostNr;
                    }
                    
                    Console.Clear();

                    sql = "UPDATE OmraadeTabel SET PersonID = " + personID + ", PostNr = " + postNr + " WHERE OmraadeID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Område opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, område IKKE opdateret");
                    }
                }
            }
        }
        #endregion
    }
}
