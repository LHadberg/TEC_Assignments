﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
namespace SydvestBo_CSHARP
{
    class Program
    {
        #region Hovedmenu
        static void Main(string[] args)
        {
            string[] valg = new string[] { "    Person Administration", "    Reservationer", "    Sommerhuse", "    Områder","    Sæsonkategori" };
            Menu m = new Menu(valg, valg.Length);
            Sommerhus s = new Sommerhus();
            PersAdmin p = new PersAdmin();
            Reservationer r = new Reservationer();
            Områder o = new Områder();
            SaesonKat k = new SaesonKat();
            bool t = true;
            while (t == true)
            {
                switch(m.SMenu())
                {
                    case 1:
                        p.UnderMenu();
                        break;
                    case 2:
                        r.KundeMenu();
                        break;
                    case 3:
                        s.Smhus();
                        break;
                    case 4:
                        o.UnderMenu();
                        break;
                    case 5:
                        k.UnderMenu();
                        break;
                }
            }
        }
        #endregion
    }
}
