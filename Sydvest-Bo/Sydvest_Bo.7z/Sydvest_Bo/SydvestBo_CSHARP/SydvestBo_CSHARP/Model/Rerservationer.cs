﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SydvestBo_CSHARP.Database;
using System.Data;
using System.Data.SqlClient;
namespace SydvestBo_CSHARP
{
    class Reservationer
    {
        #region Properties
        public int ResID { get; set; }
        public int PersonID { get; set; }
        public int HusID { get; set; }
        public int UgeNr { get; set; }
        public int Aarstal { get; set; }
        public int Pris { get; set; }
        public int KlasseID { get; set; }

        #endregion
        #region Menu til Reservationer
        public void KundeMenu()
        {
            string[] valg = new string[] { "    Opret Reservation", "    Vis Reservationer", "    Rediger Reservation", "    Slet Reservation" };
            Menu m = new Menu(valg, valg.Length);
            bool t = true;
            Menu.Watermark();
            while (t == true)
            {
                switch (m.SMenu())
                {
                    case 1:
                        Console.Clear();
                        ResCreate();
                        break;
                    case 2:
                        Console.Clear();
                        ResList();
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        ReservationerUpdate();
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        ResDelete();
                        break;
                    case -1:
                        t = false;
                        break;
                }
            }
        }
        #endregion
        #region Opret Reservation
        public void ResCreate()
        {
            PrisBeregner pris = new PrisBeregner();
            Console.CursorVisible = true;
            int PersonInput, HusInput, UgeNrInput, AarstalInput;
            Console.Write("Indtast Person ID: ");
            Console.Write("\nIndtast Hus ID   : ");
            Console.Write("\nIndtast Ugenummer: ");
            Console.Write("\nIndtast Aarstal  : ");
            Console.SetCursorPosition(22, 0);
            PersonInput = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 1);
            HusInput = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 2);
            UgeNrInput = Convert.ToInt32(Console.ReadLine());
            Console.SetCursorPosition(22, 3);
            AarstalInput = Convert.ToInt32(Console.ReadLine());
            pris.prisBeregner(out double SlutPris, HusInput, UgeNrInput);
            string sql = "insert into Reservationstabel values (" + PersonInput + ", " + HusInput + ", " + UgeNrInput + ", " + AarstalInput + ", " + SlutPris + ")";
            try
            {
                SqlConn.cnnOpen();
                SqlConn.Execute(sql);
                Console.WriteLine($"Ny Reservation oprettet i tabellen");
                SqlConn.cnnClose();
            }
            catch (Exception)
            {

                Console.WriteLine("Der opstod en fejl i oprettelsen, reservationen IKKE oprettet");
            }
            Console.ReadKey();
        }
        #endregion
        #region Reservationsconstructors
        public Reservationer(){}
        public Reservationer(int resid, int personid, int husid, int ugenr, int aarstal, int pris, int klasseID)
        {
            ResID = resid;
            PersonID = personid;
            HusID = husid;
            UgeNr = ugenr;
            Aarstal = aarstal;
            Pris = pris;
            KlasseID = klasseID;
        }
        #endregion
        #region Read Reservations Database
        public static void ResList()
        {
            string sql = "select * from Reservationstabel";
            DataTable ReservationDataTable = SqlConn.ReadTable(sql);
            List<Reservationer> reservationer = new List<Reservationer>();

            foreach (DataRow item in ReservationDataTable.Rows)
            {
                reservationer.Add(new Reservationer()
                {
                    ResID = Convert.ToInt32(item["ResID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    HusID = Convert.ToInt32(item["HusID"]),
                    UgeNr = Convert.ToInt32(item["UgeNr"]),
                    Aarstal = Convert.ToInt32(item["Aarstal"]),
                    Pris = Convert.ToInt32(item["Pris"])
                });
            }
            foreach (var item in reservationer)
            {
                Console.WriteLine("ReservationsID: {0}\nPersonID: {1}\nHusID: {2}\nUgeNr: {3}\nAarstal {4}\nPris {5} kr\n", item.ResID, item.PersonID, item.HusID, item.UgeNr, item.Aarstal, item.Pris);
            }
        }
        #endregion
        #region Update Reservation
        public void ReservationerUpdate()
        {
            int UpdateID;
            string sql = "select * from Reservationstabel";
            DataTable ReservationDataTable = SqlConn.ReadTable(sql);
            List<Reservationer> reservationer = new List<Reservationer>();

            foreach (DataRow item in ReservationDataTable.Rows)
            {
                reservationer.Add(new Reservationer()
                {
                    ResID = Convert.ToInt32(item["ResID"]),
                    PersonID = Convert.ToInt32(item["PersonID"]),
                    HusID = Convert.ToInt32(item["HusID"]),
                    UgeNr = Convert.ToInt32(item["UgeNr"]),
                    Aarstal = Convert.ToInt32(item["Aarstal"]),
                    Pris = Convert.ToInt32(item["Pris"])
                });
            }
            foreach (var item in reservationer)
            {
                Console.WriteLine("ReservationsID: {0}\nPersonID: {1}\nHusID: {2}\nUgeNr: {3}\nAarstal {4}\nPris {5} kr\n", item.ResID, item.PersonID, item.HusID, item.UgeNr, item.Aarstal, item.Pris);
            }
            Console.Write("\nSkriv ID på den reservation du vil opdatere: ");
            Console.CursorVisible = true;
            UpdateID = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Indtast Person ID: ");
            Console.Write("\nIndtast Hus ID   : ");
            Console.Write("\nIndtast Ugenummer: ");
            Console.Write("\nIndtast Aarstal  : ");
            Console.Write("\nIndtast Pris     : ");
            Console.Write("\n\n");
            foreach (var item in reservationer)
            {
                if (item.ResID == UpdateID)
                {
                    int personID;
                    int husID;
                    int ugeNr;
                    int aarstal;
                    int pris;
                    Console.WriteLine("PersonID: {0}\nHusID: {1}\nUgeNr: {2}\nAarstal {3}\nPris {4} kr\n\n",item.PersonID, item.HusID, item.UgeNr, item.Aarstal, item.Pris);

                    Console.SetCursorPosition(21, 0);
                    try
                    {
                        personID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        personID = item.PersonID;
                    }
                    Console.SetCursorPosition(21, 1);
                    try
                    {
                        husID = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        husID = item.HusID;
                    }
                    Console.SetCursorPosition(21, 2);
                    try
                    {
                        ugeNr = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        ugeNr = item.UgeNr;
                    }
                    Console.SetCursorPosition(21, 3);
                    try
                    {
                        aarstal = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        aarstal = item.Aarstal;
                    }
                    Console.SetCursorPosition(21, 4);
                    try
                    {
                        pris = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        pris = item.Pris;
                    }
                    Console.Clear();
                    sql = "UPDATE Reservationstabel SET PersonID = " + personID + ", HusID = " + husID + ", UgeNr = " + ugeNr + ", Aarstal = " + aarstal + ", Pris = " + pris + " WHERE ResID = " + UpdateID;
                    try
                    {
                        SqlConn.cnnOpen();
                        SqlConn.Execute(sql);
                        Console.WriteLine($"Reservation opdateret i tabellen");
                        SqlConn.cnnClose();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Der opstod en fejl i opdateringen, reservation IKKE opdateret");
                    }
                }
            }
        }
        #endregion
        #region Delete Reservation
        public void ResDelete()
        {
            bool forsæt = true;
            do
            {
                int deleteID;
                ConsoleKey keypressed;
                string sql = "select * from Reservationstabel";
                DataTable ReservationDataTable = SqlConn.ReadTable(sql);
                List<Reservationer> reservationer = new List<Reservationer>();

                foreach (DataRow item in ReservationDataTable.Rows)
                {
                    reservationer.Add(new Reservationer()
                    {
                        ResID = Convert.ToInt32(item["ResID"]),
                        PersonID = Convert.ToInt32(item["PersonID"]),
                        HusID = Convert.ToInt32(item["HusID"]),
                        UgeNr = Convert.ToInt32(item["UgeNr"]),
                        Aarstal = Convert.ToInt32(item["Aarstal"]),
                        Pris = Convert.ToInt32(item["Pris"])
                    });
                }
                foreach (var item in reservationer)
                {
                    Console.WriteLine("ReservationsID: {0}\nPersonID: {1}\nHusID{2}\nUgeNr{3}\nAarstal {4}\nPris {5} kr\n", item.ResID, item.PersonID, item.HusID, item.UgeNr, item.Aarstal, item.Pris);
                }
                Console.Write("\nSkriv ID på hvem du vil delete: ");
                Console.CursorVisible = true;
                deleteID = Convert.ToInt32(Console.ReadLine());
                sql = "delete from Reservationstabel where ResID=" + deleteID;
                try
                {
                    Console.Clear();
                    SqlConn.cnnOpen();
                    SqlConn.Execute(sql);
                    Console.WriteLine($"Reservartion slettet");
                    SqlConn.cnnClose();
                }
                catch (Exception)
                {
                    Console.WriteLine("Der opstod en fejl i sletningen, reservation IKKE slettet");
                }
                Console.Write("Vil du slette flere? \n(Enter = Forsæt)\n(Escape = Tilbage)");
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.Enter) forsæt = true;
                else if (keypressed == ConsoleKey.Escape) forsæt = false;
            } while (forsæt == true);
        }
        #endregion
    }
    class PrisBeregner
    {
        #region Properties
        public int KlasseID { get; set; }
        public string SaesonKategori { get; set; }
        #endregion
        #region Prisberegner
        public void prisBeregner(out double SlutPris, int HusInput = 1, int UgeNrInput = 3)
        {
            string sql = @"select  SommerhusTabel.KlasseID, SaesonKategorier.KategoriNavn from  SommerhusTabel, SaesonKategorier where " + HusInput + " = SommerhusTabel.HusID AND " + UgeNrInput + " = SaesonKategorier.UgeNr";
            DataTable ResTabel = SqlConn.ReadTable(sql);
            foreach (DataRow item in ResTabel.Rows)
            {
                KlasseID = Convert.ToInt32(item["KlasseID"]);
                SaesonKategori = item["KategoriNavn"].ToString();
            }
            SlutPris = 0;
            double FørstePris = 0;
            if (KlasseID == 1) FørstePris = 2000;
            else if (KlasseID == 2) FørstePris = 3000;
            else if (KlasseID == 3) FørstePris = 4000;
            else if (KlasseID == 4) FørstePris = 5000;
            else if (KlasseID == 5) FørstePris = 6000;
            else if (KlasseID == 6) FørstePris = 7000;
            if (SaesonKategori == "Lav") SlutPris = FørstePris * 0.8;
            if (SaesonKategori == "Normal") SlutPris = FørstePris * 1.1;
            if (SaesonKategori == "Høj") SlutPris = FørstePris * 1.3;
            if (SaesonKategori == "Super") SlutPris = FørstePris * 2;
        }
        #endregion
    }
}