﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using SydvestBo_CSHARP.Database;
namespace SydvestBo_CSHARP
{
    public class Menu
    {
        #region Properties
        public static int X { get; set; }
        public string[] Valg = new string[X];
        #endregion
        #region Menuconstructors
        public Menu(string[] valg, int x)
        {
            Valg = valg;
            X = x;
        }
        public Menu(){}
        #endregion
        #region Cursormenu
        public int SMenu()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.CursorVisible = false;
            Console.Clear();
            Watermark();
            Console.Title = "Sydvest-Bo[dil] Lejeforening";
            int i = 0;
            int coordX = Console.CursorLeft;
            int coordY = Console.CursorTop;
            int b = 1;
            foreach (var item in Valg)
            {
                Console.WriteLine(item);
            }
            Console.SetCursorPosition(0, 0);
            Console.Write("->");
            Console.SetCursorPosition(coordX, coordY);
            ConsoleKey keypressed;
            while (i == 0)
            {
                keypressed = Console.ReadKey(true).Key;
                if (keypressed == ConsoleKey.DownArrow)
                {
                    setPos();
                    Console.Write("  ");
                    Console.SetCursorPosition(coordX, coordY);
                    if (Console.CursorTop == Valg.Length - 1)
                    {
                        b = 1;
                        Console.SetCursorPosition(0, 0);
                        setPos();
                        Console.Write("->");
                        Console.SetCursorPosition(coordX, coordY);
                    }
                    else
                    {
                        b += 1;
                        Console.SetCursorPosition(0, Console.CursorTop + 1);
                        setPos();
                        Console.Write("->");
                        Console.SetCursorPosition(coordX, coordY);
                    }
                }
                else if (keypressed == ConsoleKey.UpArrow)
                {
                    setPos();
                    Console.Write("  ");
                    Console.SetCursorPosition(coordX, coordY);
                    if (Console.CursorTop == 0)
                    {
                        b = Valg.Length;
                        Console.SetCursorPosition(0, Valg.Length - 1);
                        setPos();
                        Console.Write("->");
                        Console.SetCursorPosition(coordX, coordY);
                    }
                    else
                    {
                        b += -1;
                        Console.SetCursorPosition(0, Console.CursorTop - 1);
                        setPos();
                        Console.Write("->");
                        Console.SetCursorPosition(coordX, coordY);
                    }
                }
                else if (keypressed == ConsoleKey.Enter)
                {
                    i = b;
                    return i;
                }
                else if (keypressed == ConsoleKey.Backspace)
                {
                    i = -1;
                    return i;
                }
                else if (keypressed == ConsoleKey.Escape)
                {
                    Environment.Exit(0);
                }
            }
            void setPos()
            {
                coordX = Console.CursorLeft;
                coordY = Console.CursorTop;
            }
            return i;
        }
        public static void Watermark()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.SetCursorPosition(88, 1);
            Console.WriteLine(@" /$$       /$$$$$$$$ /$$$$$$$ ");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 2);
            Console.WriteLine(@"| $$      | $$_____/| $$__  $$");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 3);
            Console.WriteLine(@"| $$      | $$      | $$  \ $$");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 4);
            Console.WriteLine(@"| $$      | $$$$$   | $$  | $$");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 5);
            Console.WriteLine(@"| $$      | $$__/   | $$  | $$");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 6);
            Console.WriteLine(@"| $$      | $$      | $$  | $$");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 7);
            Console.WriteLine(@"| $$$$$$$$| $$$$$$$$| $$$$$$$/");
            Thread.Sleep(50);
            Console.SetCursorPosition(88, 8);
            Console.WriteLine(@"|________/|________/|_______/");
            Console.SetCursorPosition(79, 25);
            Console.WriteLine("Tast ↑ eller ↓ for at navigere i menuen ");
            Console.SetCursorPosition(84, 26);
            Console.WriteLine("Tast 'Enter' for at vælge en menu.");
            Console.SetCursorPosition(83, 27);
            Console.WriteLine("Tast 'Backspace' for at gå tilbage.");
            Console.SetCursorPosition(83, 28);
            Console.WriteLine("Tast 'Esc' for at lukke programmet.");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(0, 0);
        }

        public static void WatermarkRGB()
        {
            Console.SetCursorPosition(88, 1);
            string l1=@" /$$       /$$$$$$$$ /$$$$$$$ ";
            string l2=@"| $$      | $$_____/| $$__  $$";
            string l3=@"| $$      | $$      | $$  \ $$";
            string l4=@"| $$      | $$$$$   | $$  | $$";
            string l5=@"| $$      | $$__/   | $$  | $$";
            string l6=@"| $$      | $$      | $$  | $$";
            string l7=@"| $$$$$$$$| $$$$$$$$| $$$$$$$/";
            string l8=@"|________/|________/|_______/";
            char[] c1 = l1.ToCharArray();
            char[] c2 = l2.ToCharArray();
            char[] c3 = l3.ToCharArray();
            char[] c4 = l4.ToCharArray();
            char[] c5 = l5.ToCharArray();
            char[] c6 = l6.ToCharArray();
            char[] c7 = l7.ToCharArray();
            char[] c8 = l8.ToCharArray();
            Console.SetCursorPosition(88, 1);
            foreach (var item in c1)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 2);
            foreach (var item in c2)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 3);
            foreach (var item in c3)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 4);
            foreach (var item in c4)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 5);
            foreach (var item in c5)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 6);
            foreach (var item in c6)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 7);
            foreach (var item in c7)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.SetCursorPosition(88, 8);
            foreach (var item in c8)
            {
                GenerateColour();
                Console.Write(item);
                Thread.Sleep(5);
            }
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(79, 25);
            Console.WriteLine("Tast ↑ eller ↓ for at navigere i menuen ");
            Console.SetCursorPosition(84, 26);
            Console.WriteLine("Tast 'Enter' for at vælge en menu.");
            Console.SetCursorPosition(83, 27);
            Console.WriteLine("Tast 'Backspace' for at gå tilbage.");
            Console.SetCursorPosition(83, 28);
            Console.WriteLine("Tast 'Esc' for at lukke programmet.");
            Console.SetCursorPosition(0, 0);
        }
        public static void GenerateColour()
        {

            Random r = new Random();
            int ra = r.Next(1, 5);
            if(ra==1)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
            }
            else if(ra==2)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else if (ra == 3)
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            else if (ra == 4)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            else if (ra == 5)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
            }
        }
        #endregion
    }
}
